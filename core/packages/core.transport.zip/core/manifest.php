<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'b2254cedf73a756c4ab3f263a89064f7',
      'native_key' => 'core',
      'filename' => 'modNamespace/cf4823b7ade3d3f877e0f27d46e3e48b.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modWorkspace',
      'guid' => 'b04470d992508fbc9369b3981ea773fc',
      'native_key' => 1,
      'filename' => 'modWorkspace/11ef73c4a02d3ff536b887189480f1ce.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTransportProvider',
      'guid' => '993cc113aef586ae27556b307e1c830d',
      'native_key' => 1,
      'filename' => 'modTransportProvider/7f628de84d0f4f2c67d123668631c586.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '82d6f38a5fea8c88969380d7ec913591',
      'native_key' => 'topnav',
      'filename' => 'modMenu/e3bf292a03891546d318dbae63bde72f.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '31a4b2f23f086dc0322ed5b959574d9d',
      'native_key' => 'usernav',
      'filename' => 'modMenu/23eefb20594f3ced19c10b288f35cf7c.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '7e26ac5d03874c9ef7dd70e547c58f8d',
      'native_key' => 1,
      'filename' => 'modContentType/0672aa3eb8faf4c975c5a2b738831afe.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '18f187cc22a6176c8ae0ff3bcbf82fa8',
      'native_key' => 2,
      'filename' => 'modContentType/4e03a32740d02759a84d07f1be1d5207.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '1f1b2c34120613f828e0f2c6ca545e6a',
      'native_key' => 3,
      'filename' => 'modContentType/9325a1180b9cee7ee21f246acbf2e372.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '96ddc0f571ca5d32708154eb0ad4883d',
      'native_key' => 4,
      'filename' => 'modContentType/fda022a525dd478a2f6e94b2b4fd594a.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '03937d3e6c7578a2e0ec1d5b7ebce693',
      'native_key' => 5,
      'filename' => 'modContentType/ebff727802bb87db890db30b1d28d3c2.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'e394e33eb04fdd2b5bf35fe9d941cafc',
      'native_key' => 6,
      'filename' => 'modContentType/cd1fe189da981e88282ddd9adadf7bed.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'f27622c8228759c18b0e08f3d58416de',
      'native_key' => 7,
      'filename' => 'modContentType/1d646cff4524f4933301e90b298bc225.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '6364e6a86ba023727ddb939c5c82d7c4',
      'native_key' => 8,
      'filename' => 'modContentType/bb7e806d28ee950210d2e9051443ea00.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'ad35c846ae4791d0307eeef528850abc',
      'native_key' => NULL,
      'filename' => 'modClassMap/8a320f30dffb4f4ec2ab8e1e18116f21.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '0b046e5282caff3a005777fab2564a61',
      'native_key' => NULL,
      'filename' => 'modClassMap/6ba138602be8694a13fe1cd6e37f3497.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '591db7f0ad4c7b783f6781f71264624d',
      'native_key' => NULL,
      'filename' => 'modClassMap/3772b745b1359da717712b875214d48c.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'e7120d3b9f063769c66e51971c643da9',
      'native_key' => NULL,
      'filename' => 'modClassMap/9f6fe1d98b68d3178e672d9c4f2146f2.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'd90073521a6665fea39c8ade833e78ee',
      'native_key' => NULL,
      'filename' => 'modClassMap/7dc0ee0aeb5bf2cd404688891a2a7a5a.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '31dc88ac078963fb846e9f978cbd3c26',
      'native_key' => NULL,
      'filename' => 'modClassMap/f7401db506962a8cbd2d9bc9f99665e3.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '65713315cc2dd26061f4772abfe96355',
      'native_key' => NULL,
      'filename' => 'modClassMap/976afa892bcf5a2036ad7927524ff160.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '7cb4c4c4feb13c28247aaa015a85746f',
      'native_key' => NULL,
      'filename' => 'modClassMap/d7aceaa672900b3b98eab94d7c642cd1.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'b95778c2f6b54b63e0b02f6b92e22ee7',
      'native_key' => NULL,
      'filename' => 'modClassMap/8d53b3abab6f27636307a82712feaf69.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '079a49aa1b2cce9ae399c74b3a57cd36',
      'native_key' => 'OnPluginEventBeforeSave',
      'filename' => 'modEvent/1acb2ed06d8ff5acfa8c5e3acf23431e.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '85517938c8844f0ef7aa681276557522',
      'native_key' => 'OnPluginEventSave',
      'filename' => 'modEvent/5b034633e555db9c3732d705d0bc8641.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd0a2dad67f298c21026dd1d550eaeb16',
      'native_key' => 'OnPluginEventBeforeRemove',
      'filename' => 'modEvent/dbf1f11d8d992dd56a23b34ac9f09ce1.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9bb4183c50fbfd124e7b4103a3902200',
      'native_key' => 'OnPluginEventRemove',
      'filename' => 'modEvent/144fef297081834a21240d1b60c5acb1.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '61bf9ce4fad6797aaf737e3b2eaff396',
      'native_key' => 'OnResourceGroupSave',
      'filename' => 'modEvent/8d237b7504817e76dbd3772f567c81eb.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '83e06856de1b67793829351ee4d3378f',
      'native_key' => 'OnResourceGroupBeforeSave',
      'filename' => 'modEvent/66dad0d626c1c1d63be049a43a1dc8b9.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '38e61ecf50ef79885591056b2ca524b5',
      'native_key' => 'OnResourceGroupRemove',
      'filename' => 'modEvent/5047f0920f7d8780b3cf30587eca9548.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a1a55012dbed67f8cf31b37c43a8f434',
      'native_key' => 'OnResourceGroupBeforeRemove',
      'filename' => 'modEvent/a85dfd628ebcfc51ca4534f20f5daf48.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5653ab45cac7b6293803e2152006c239',
      'native_key' => 'OnSnippetBeforeSave',
      'filename' => 'modEvent/033e054a8c767edf3c34e649f348aa59.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b6acbe0bb2d8ebc4c5a39ddda92e7bb5',
      'native_key' => 'OnSnippetSave',
      'filename' => 'modEvent/58bd425b223c151cbcc09f9929f54ed6.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e7f18912f007223d5773fc8de02e849b',
      'native_key' => 'OnSnippetBeforeRemove',
      'filename' => 'modEvent/a8b2e517b69d4b3bdb6c42b5cb6a3679.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '28e836c0249ca5cf17d53a8542a35524',
      'native_key' => 'OnSnippetRemove',
      'filename' => 'modEvent/2f4143b3ff40c431d22ed4fef564b288.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '37cb5a70997601b87ab7d9b61b07d104',
      'native_key' => 'OnSnipFormPrerender',
      'filename' => 'modEvent/f629e73c762ba32e01c77181cdedf621.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'da46ef45ec196cc64ad5e3182f85c602',
      'native_key' => 'OnSnipFormRender',
      'filename' => 'modEvent/d1176fd2fceb87d703794432cb724915.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7c447ba263a79c3eda01da7a7e8ad535',
      'native_key' => 'OnBeforeSnipFormSave',
      'filename' => 'modEvent/2f5acc38b1e6b3d0464690ae5ba5a86f.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2731b72e21558d0defe2cacff6626b1f',
      'native_key' => 'OnSnipFormSave',
      'filename' => 'modEvent/38f28c92ba010e5ba1ded6a3f2e9447a.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '66a83ff790b21ba6b973dc211ce7d175',
      'native_key' => 'OnBeforeSnipFormDelete',
      'filename' => 'modEvent/7c4fce2289434fc812f1945ab0abd392.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '52bf7e272c6700d3017a73a9fd5f4548',
      'native_key' => 'OnSnipFormDelete',
      'filename' => 'modEvent/726bdd81efb0d0a1fd062dd5ba170caf.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '83b15f9127c7b2fe0ba102d60ae4cdb0',
      'native_key' => 'OnTemplateBeforeSave',
      'filename' => 'modEvent/5b866c0828b77224c830ef272f32e5be.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fe94f10ec624fc259c9650c2da3c5406',
      'native_key' => 'OnTemplateSave',
      'filename' => 'modEvent/ecc3aa6fddcac6e6bb98f41b50e871ff.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3f31f3c868fa146310a4be035833d04d',
      'native_key' => 'OnTemplateBeforeRemove',
      'filename' => 'modEvent/e7e24ba3f5852e79713f58e9e9b6042c.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b8f302108db9d8f7a92c7da4e854b36d',
      'native_key' => 'OnTemplateRemove',
      'filename' => 'modEvent/f671f4a277778015cc5836b04e07a190.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b8d63c50c8fa774d7e986020bf5f693f',
      'native_key' => 'OnTempFormPrerender',
      'filename' => 'modEvent/cab087f7a99531d5b574863611de9f68.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c8f585008c23d918acc5be0a6c496209',
      'native_key' => 'OnTempFormRender',
      'filename' => 'modEvent/7772c42cd7e447504147c19c0face3b0.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8bc90c7c6a9f425319599bfbd1c96711',
      'native_key' => 'OnBeforeTempFormSave',
      'filename' => 'modEvent/efee7dc8889b18394d6c55590ffe2ebe.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f17e65643eccd81a18c695bf19ecab38',
      'native_key' => 'OnTempFormSave',
      'filename' => 'modEvent/f8b1d0f05865d763126e2d6322e06069.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7cddcf97652904ab854e2a7e3767f342',
      'native_key' => 'OnBeforeTempFormDelete',
      'filename' => 'modEvent/0033af04beb7f6975616117ff2ffd8a7.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '722865a4c368a2d4b72744991bbfb6a2',
      'native_key' => 'OnTempFormDelete',
      'filename' => 'modEvent/59379738016a7d3e0bf920778fbc180c.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '083a8f3f548b62e9c1c461aff44440b6',
      'native_key' => 'OnTemplateVarBeforeSave',
      'filename' => 'modEvent/2b5aeaebf98ce29249dc2bcc19ed8a89.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a8fb1162ed64d7c02647010529e79683',
      'native_key' => 'OnTemplateVarSave',
      'filename' => 'modEvent/f02c5b39a1eb88042aaaaddd202dd489.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9e13cc4be1b61be78d7a78a293a3b515',
      'native_key' => 'OnTemplateVarBeforeRemove',
      'filename' => 'modEvent/30f6876692923e4359c823e7c0162c55.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5992ab8a0566964d360de74f7c51d7a4',
      'native_key' => 'OnTemplateVarRemove',
      'filename' => 'modEvent/6a4f0a850b10cfe724b461bdd24a2e46.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '441e3a5c6b6004aef606ffe18085d5df',
      'native_key' => 'OnTVFormPrerender',
      'filename' => 'modEvent/67e00df37dbf5ed4f9ba344ca207f7ae.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dd65d5ee9d787956ab5cbb51c04446d8',
      'native_key' => 'OnTVFormRender',
      'filename' => 'modEvent/03debf8e93e7b3e19d212caf8877a727.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0f8c4996a1d5b442017d4f8854bd3409',
      'native_key' => 'OnBeforeTVFormSave',
      'filename' => 'modEvent/6912f6fd70142aa74357ede124a599ed.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '164da7222d234f04ca3141c407f5b08e',
      'native_key' => 'OnTVFormSave',
      'filename' => 'modEvent/d8127bb1350c1e0dc523a94024671a64.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7c4bea38e2aef19c8702029da9cb321a',
      'native_key' => 'OnBeforeTVFormDelete',
      'filename' => 'modEvent/8f1db2eedc1ab04439a76239eedbde9c.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8cda40c258a510e58bb4df327e8eadc9',
      'native_key' => 'OnTVFormDelete',
      'filename' => 'modEvent/80f58ba315d44a65322e4d29294fa14f.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b52bc9c204b59b66994a350477d4320d',
      'native_key' => 'OnTVInputRenderList',
      'filename' => 'modEvent/0cc73d0d5b775fc3d2d8c90422707f9e.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ab4ed33d48bbb894d523d554b294e157',
      'native_key' => 'OnTVInputPropertiesList',
      'filename' => 'modEvent/6f0dcba64e1772b437b0d9823755b84a.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e4165a6bed600c558afb746960fd7047',
      'native_key' => 'OnTVOutputRenderList',
      'filename' => 'modEvent/13f454cf0dcb5df4be77630f7f7710f7.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e34760062d5ea35e36900d8100e0ffa6',
      'native_key' => 'OnTVOutputRenderPropertiesList',
      'filename' => 'modEvent/24431cf81c2f1df5e3cf527157356093.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a9dad18bda14d9f29b8f9a455804ce4f',
      'native_key' => 'OnUserGroupBeforeSave',
      'filename' => 'modEvent/9a862b937275144ad44a870576a63db8.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5172c6500eaf803e0929d0fa8e9ec3f6',
      'native_key' => 'OnUserGroupSave',
      'filename' => 'modEvent/3bc2cd394583a40c28bad130745a90e6.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0259d1ff049d58e0edd04a9cd43910fb',
      'native_key' => 'OnUserGroupBeforeRemove',
      'filename' => 'modEvent/b582151e8624f886611aa6325f8b586b.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2dc318b7702e2f46b916e684254e2e0e',
      'native_key' => 'OnUserGroupRemove',
      'filename' => 'modEvent/305a126dea810ff5db1081509e59fe5b.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd290e1c035374d7ebd8dcdac6891cef9',
      'native_key' => 'OnBeforeUserGroupFormSave',
      'filename' => 'modEvent/c753ebab0e5af2e8ad25a1741f2e9ae8.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '04112bdcfc3295303818d76259e52f9d',
      'native_key' => 'OnUserGroupFormSave',
      'filename' => 'modEvent/94d92fa5bf11e0a71449c849251e8c5a.vehicle',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '30acc8cf728eb29412e50c65779b8277',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/a97e75226577f866727cbfc3df3ee334.vehicle',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '88e66a4d894df1c1f50580f9c8c8c335',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/99b82e5457e16d62d4038574e8476354.vehicle',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '623d20e3adcc32b0a0d8e186ec3194f7',
      'native_key' => 'OnDocFormPrerender',
      'filename' => 'modEvent/49aae9f7f07861f0bf49c72ca32306b9.vehicle',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c6799173cc1de6dee4df4d030d23c72a',
      'native_key' => 'OnDocFormRender',
      'filename' => 'modEvent/2693627b6792fd9d8416481ae3390519.vehicle',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a45691dd0127e9be998c9876785ea638',
      'native_key' => 'OnBeforeDocFormSave',
      'filename' => 'modEvent/2944e68d0894aa8f3993ffacbdc15c91.vehicle',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '364e6c57e2c03c6945e3cc29d984ceb5',
      'native_key' => 'OnDocFormSave',
      'filename' => 'modEvent/8f3c2ecc4898067bd67a3ae098ef7845.vehicle',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '98c5ab20c6cead88a0596d10dc6581c2',
      'native_key' => 'OnBeforeDocFormDelete',
      'filename' => 'modEvent/d8c7bdd291e8da1be53defa24f521785.vehicle',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b6dcaceb42274f801f9acc8948908d13',
      'native_key' => 'OnDocFormDelete',
      'filename' => 'modEvent/a1ffc208da4e2659b4518bccb0687c13.vehicle',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '496bba3c44fe55b78c4211349720278b',
      'native_key' => 'OnDocPublished',
      'filename' => 'modEvent/b1da55fd733e24d8c3ed9351342a934b.vehicle',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6e50c2bb614da8db03cfbe956c9ae0d7',
      'native_key' => 'OnDocUnPublished',
      'filename' => 'modEvent/e53d37d3ed8856d12e89270007c8a39a.vehicle',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '426c2c1182080816c20086f71ed4c06d',
      'native_key' => 'OnBeforeEmptyTrash',
      'filename' => 'modEvent/60da8a44f7152983ccd7d7216bce217a.vehicle',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ee1b1da7c69280d986a1a633c24d084a',
      'native_key' => 'OnEmptyTrash',
      'filename' => 'modEvent/c68262201c7f03eeedbc85383e697d86.vehicle',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '73b73321c012bba31ea2c539d2a4b022',
      'native_key' => 'OnResourceTVFormPrerender',
      'filename' => 'modEvent/a76f955ebb8dd6dfec96b2ace9d4d242.vehicle',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '38de8aaf90995df10ef5c8384db75872',
      'native_key' => 'OnResourceTVFormRender',
      'filename' => 'modEvent/9cfb9c53413406e8f6b33188805e88ae.vehicle',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '13046a4916aae0573ab60f12d58ed198',
      'native_key' => 'OnResourceAutoPublish',
      'filename' => 'modEvent/d100d0db44a8b35095553068eac9474f.vehicle',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '17b20e7bc9b5246d42b022bc60a64d64',
      'native_key' => 'OnResourceDelete',
      'filename' => 'modEvent/9e405bd99d3b0755c09e347d6ddfc717.vehicle',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c9f068a7b97bd11ef0ee1415ed0a4056',
      'native_key' => 'OnResourceUndelete',
      'filename' => 'modEvent/f5bf7149c54839630f7a2bac325b256d.vehicle',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a22982d0e7970ce2bb17789b738d074b',
      'native_key' => 'OnResourceBeforeSort',
      'filename' => 'modEvent/4260e8456a7beaf1b09efe6450faa239.vehicle',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a5321cd10a89c4e0434b6cf14bc3381e',
      'native_key' => 'OnResourceSort',
      'filename' => 'modEvent/b491ee45748a9359051ffee5ed6359a1.vehicle',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '690c7a5cc51d42afebcad3dc4b684209',
      'native_key' => 'OnResourceDuplicate',
      'filename' => 'modEvent/cc0241262a95ec30e1afef8603f5130b.vehicle',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '52b511b93f5b433d646e5250e5d2a5c2',
      'native_key' => 'OnResourceToolbarLoad',
      'filename' => 'modEvent/6d23921a261b465c549efc05c9bc4f43.vehicle',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '94d6b22a0fa5999d2d197bfb9765b67c',
      'native_key' => 'OnResourceRemoveFromResourceGroup',
      'filename' => 'modEvent/dbc6c782e7f3ccd2b917641f3b539f40.vehicle',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dc5961c782ed84c20ae6822d95a46373',
      'native_key' => 'OnResourceAddToResourceGroup',
      'filename' => 'modEvent/f97c9cbb4b8eeb6d77e94d0b75fdb17e.vehicle',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f04e1794248b0233e8a0be27c1d71c06',
      'native_key' => 'OnRichTextEditorRegister',
      'filename' => 'modEvent/697a332a5713aaf010a1fb28ec1fe73f.vehicle',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '67ec2fbf506454eddd679026b7793cfa',
      'native_key' => 'OnRichTextEditorInit',
      'filename' => 'modEvent/ece3d2e0e953ae65bbfff51cac9f59dc.vehicle',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '707ba19d3e5d2871ec44b06d7fca72b1',
      'native_key' => 'OnRichTextBrowserInit',
      'filename' => 'modEvent/c64cdece8888e00bf717773584720058.vehicle',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4b188978bfae428d846a8746c4d58c1d',
      'native_key' => 'OnWebLogin',
      'filename' => 'modEvent/7db9fe9bce2461cb07232d5c47bc534d.vehicle',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '06769413c2210c5483da268fc3e0814f',
      'native_key' => 'OnBeforeWebLogout',
      'filename' => 'modEvent/8dcf90a53902fece14c9f6292abcdf9a.vehicle',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e418f1c4482e1beb83b43847a6c7fd58',
      'native_key' => 'OnWebLogout',
      'filename' => 'modEvent/1de1ba2ac3d3b9cda305bb5e7a241a86.vehicle',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '15b0b2152f7491bf2fc918291e36db1e',
      'native_key' => 'OnManagerLogin',
      'filename' => 'modEvent/00938e3d65ea6efd2181a3b8a4995ea8.vehicle',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2d044459afba6b8647c18fdaaf64f3e6',
      'native_key' => 'OnBeforeManagerLogout',
      'filename' => 'modEvent/81a3716d5a0103a6236fe77b58c0e1ad.vehicle',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dbf446f3381bcd8077ca3cc6346cca6f',
      'native_key' => 'OnManagerLogout',
      'filename' => 'modEvent/c08d042cfaace6a12b0b2efc50ce2924.vehicle',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '336b22f26a0e118812c651dcc73bc03a',
      'native_key' => 'OnBeforeWebLogin',
      'filename' => 'modEvent/91bd1369005aa538edb556f6cd907ee7.vehicle',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd4d9b4a0b9c122c1fedde7b8ef3d8862',
      'native_key' => 'OnWebAuthentication',
      'filename' => 'modEvent/8058269e280293e9a41d9b2cda94244f.vehicle',
    ),
    104 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ee0d6336846374d3fc6b932b7fe71154',
      'native_key' => 'OnBeforeManagerLogin',
      'filename' => 'modEvent/b80d469bfab53773669b22b7db9043b8.vehicle',
    ),
    105 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd438e6bec489c92a4016ef6bb04aa8b0',
      'native_key' => 'OnManagerAuthentication',
      'filename' => 'modEvent/60603d94c4b67d5eb866971512b9dda5.vehicle',
    ),
    106 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ec981bde5a19b117aa8e3ffe85e6d8da',
      'native_key' => 'OnManagerLoginFormRender',
      'filename' => 'modEvent/ab77e0a452e76b9946bd108973d3af34.vehicle',
    ),
    107 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'db3bb2be197e7c0b59decccc0a059e5f',
      'native_key' => 'OnManagerLoginFormPrerender',
      'filename' => 'modEvent/6bf38c7e0f7528b70e61cd7e022ebf8f.vehicle',
    ),
    108 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0872dbc4b3a8621847e3e8454ea30fd9',
      'native_key' => 'OnPageUnauthorized',
      'filename' => 'modEvent/72de6615f574254b657245c8538ef4ee.vehicle',
    ),
    109 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c34baf810c8a7dae4a8cad4ce5791b30',
      'native_key' => 'OnUserFormPrerender',
      'filename' => 'modEvent/8c14190c145f3fa5d932999cbf11a82d.vehicle',
    ),
    110 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bc9fc2a5cee49c5cb9ac784ee39b2642',
      'native_key' => 'OnUserFormRender',
      'filename' => 'modEvent/1a63cd1b47b011a992bec2dc7ed2e29e.vehicle',
    ),
    111 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3806a28dfa251e758d48f6a21354e577',
      'native_key' => 'OnBeforeUserFormSave',
      'filename' => 'modEvent/0e49a0a2883bf68c8d2f70b7baadea9f.vehicle',
    ),
    112 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '15defdcd2b11444bd28d872b8cddc7c8',
      'native_key' => 'OnUserFormSave',
      'filename' => 'modEvent/5ddcf5137af83752008dab981f4c3a22.vehicle',
    ),
    113 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3e623639f0aadbe02e4bec8531b1339b',
      'native_key' => 'OnBeforeUserFormDelete',
      'filename' => 'modEvent/27cb7fc3565c646cd8f227cfa012c36d.vehicle',
    ),
    114 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8372ad4c9e1de3471a40b560a9665831',
      'native_key' => 'OnUserFormDelete',
      'filename' => 'modEvent/415f06655fc0c85d087e3e22cfb8644e.vehicle',
    ),
    115 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2ba8b75c5f8f51d70ab92650d8602f8d',
      'native_key' => 'OnUserNotFound',
      'filename' => 'modEvent/bf8272ea9869fa32bfff648e8e8dcf1e.vehicle',
    ),
    116 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3db86c8a3c3e7c18fcd98930571992e4',
      'native_key' => 'OnBeforeUserActivate',
      'filename' => 'modEvent/9cf631a7e754bf3a18a7a8a7b5ad97e1.vehicle',
    ),
    117 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3c98f4c7463e9b8b816f391e85db7f23',
      'native_key' => 'OnUserActivate',
      'filename' => 'modEvent/b879c792176d95de16a1c388bc7d758e.vehicle',
    ),
    118 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '85b8e69822f0b6b5b8e393fbb6573e2b',
      'native_key' => 'OnBeforeUserDeactivate',
      'filename' => 'modEvent/a386436fcf86b41d38421c6bb24e649f.vehicle',
    ),
    119 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '68fda80d4ee2c6e5d9d4aa7b7cd4e346',
      'native_key' => 'OnUserDeactivate',
      'filename' => 'modEvent/4fb6b8cc93c29413baf4a6398631f01a.vehicle',
    ),
    120 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cc504dac5b193d15b625cb604d38b670',
      'native_key' => 'OnBeforeUserDuplicate',
      'filename' => 'modEvent/d492aaa9cbc87212a04607fef112874d.vehicle',
    ),
    121 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c233888524b70885c3579e8a227c49a5',
      'native_key' => 'OnUserDuplicate',
      'filename' => 'modEvent/1bce0c36a72ff2dc7791f0495f456e0b.vehicle',
    ),
    122 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ea182eca8c2b10e741c0af19850e9146',
      'native_key' => 'OnUserChangePassword',
      'filename' => 'modEvent/f6f326fe0ad17fb1220aac22b6c617bc.vehicle',
    ),
    123 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5c804cb73e662719a6ae214da5cb32cb',
      'native_key' => 'OnUserBeforeRemove',
      'filename' => 'modEvent/8b6ec563b990fcf0d9ce8432df9ef5db.vehicle',
    ),
    124 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6cf86d94508c8c4722289d4cac09d675',
      'native_key' => 'OnUserBeforeSave',
      'filename' => 'modEvent/20032de19edd8ca0f41dac1ec1a68399.vehicle',
    ),
    125 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2201696a9b170ae6fe4fd69425e05fb5',
      'native_key' => 'OnUserSave',
      'filename' => 'modEvent/7c928297429e990876b282c8f5f20120.vehicle',
    ),
    126 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9133c6a783b690dd1c5be9cd6efcf7d2',
      'native_key' => 'OnUserRemove',
      'filename' => 'modEvent/bc2b4c82368dbae3e3ae9698c54767a5.vehicle',
    ),
    127 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a85f11e34c62caa135d53d7d95d2d74f',
      'native_key' => 'OnUserBeforeAddToGroup',
      'filename' => 'modEvent/99db8e70290cda8efaa33c7b69ff0c0a.vehicle',
    ),
    128 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '86c0c83664306f8b1ddbbabd5cf77dd2',
      'native_key' => 'OnUserAddToGroup',
      'filename' => 'modEvent/20770cdf0e65b6833998ada74fe65a96.vehicle',
    ),
    129 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '373f42188ce224f806700f93dda2c5cd',
      'native_key' => 'OnUserBeforeRemoveFromGroup',
      'filename' => 'modEvent/6a891241bed05adc91df1a0023957ade.vehicle',
    ),
    130 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7037b95b48f9d3c71397b0bf151ab6da',
      'native_key' => 'OnUserRemoveFromGroup',
      'filename' => 'modEvent/cd430435fa91313fb74edb1d8cad0517.vehicle',
    ),
    131 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3d02f27bc2a46477e077d132963e8fda',
      'native_key' => 'OnWebPagePrerender',
      'filename' => 'modEvent/781e48bf22781775c4b639861f13764a.vehicle',
    ),
    132 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c836776da57ed5c766cde753af6ccced',
      'native_key' => 'OnBeforeCacheUpdate',
      'filename' => 'modEvent/82fa5ccd7899126c8c8cf69241d509ba.vehicle',
    ),
    133 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ce131a68fd840fde6cec6a58f829580d',
      'native_key' => 'OnCacheUpdate',
      'filename' => 'modEvent/ecaa787cd4ece023dc21952a6d5688ec.vehicle',
    ),
    134 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '886eb3317f5e153972479294aa64f4a8',
      'native_key' => 'OnLoadWebPageCache',
      'filename' => 'modEvent/f8731ac0da794fe66f6091bb3db25f1c.vehicle',
    ),
    135 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c8ed2468dd3b38c34f093fd417e1b46b',
      'native_key' => 'OnBeforeSaveWebPageCache',
      'filename' => 'modEvent/a93c854ff0b645c4e18ce89d7606a883.vehicle',
    ),
    136 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1e9c53f1c84353317c26a251599aa9a4',
      'native_key' => 'OnSiteRefresh',
      'filename' => 'modEvent/1d0c57fa717de60897e7cf9dc04432d5.vehicle',
    ),
    137 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6ea61cedabee4a8b37de549058877273',
      'native_key' => 'OnFileManagerDirCreate',
      'filename' => 'modEvent/4859c03ac16d6633fb1120018c40f04d.vehicle',
    ),
    138 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '47bc24ae0011372504946ac601965c22',
      'native_key' => 'OnFileManagerDirRemove',
      'filename' => 'modEvent/bf478047eff6baa2e9b8e17c8a6512fe.vehicle',
    ),
    139 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '939e94a321c1f69ad806646b42a1d253',
      'native_key' => 'OnFileManagerDirRename',
      'filename' => 'modEvent/91798630365dc05fe77dd1faf5573a79.vehicle',
    ),
    140 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2ab9f91235694e71a65ac439d07a2d44',
      'native_key' => 'OnFileManagerFileRename',
      'filename' => 'modEvent/aec079e6b07c61bc5bc26759510ff489.vehicle',
    ),
    141 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2f1cdd8edb64b49e2663032a3b90dcfb',
      'native_key' => 'OnFileManagerFileRemove',
      'filename' => 'modEvent/8f971e868b7fae7a5ddaafe6318362ec.vehicle',
    ),
    142 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7c5fe61710e7399582b0db81f6b5d64c',
      'native_key' => 'OnFileManagerFileUpdate',
      'filename' => 'modEvent/60122e2d2bab83cc6fbd8ab5b08b849e.vehicle',
    ),
    143 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '821786076d1faab964ec6d7a0c89e632',
      'native_key' => 'OnFileManagerFileCreate',
      'filename' => 'modEvent/b67e6a00c31e48fa4eb409f13f50699f.vehicle',
    ),
    144 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '464cf6efdd35ed1de27b4bf92a52ee6a',
      'native_key' => 'OnFileManagerBeforeUpload',
      'filename' => 'modEvent/badc2efddeb7dcfaae8ce3fa3c98cfac.vehicle',
    ),
    145 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0b9d7e132773d2e758838eb7125a75ab',
      'native_key' => 'OnFileManagerUpload',
      'filename' => 'modEvent/37bf396ea73343e1ed4e38da321a3de7.vehicle',
    ),
    146 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6e2936fc6f58ca6171d79bccd268e859',
      'native_key' => 'OnFileManagerMoveObject',
      'filename' => 'modEvent/ef100ce363309c3e876b22c26e98a7ba.vehicle',
    ),
    147 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '07c266ac8c918143116737936e1b13f0',
      'native_key' => 'OnFileCreateFormPrerender',
      'filename' => 'modEvent/e698c8de4b1be1342d0cb5b91e64860f.vehicle',
    ),
    148 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c4fa58b0ed110f5766eca9ce1727a17d',
      'native_key' => 'OnFileEditFormPrerender',
      'filename' => 'modEvent/902558b163a6f09df6497b81a9ae5937.vehicle',
    ),
    149 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '33ecdd69455464a3cebef8adaa51bbf3',
      'native_key' => 'OnManagerPageInit',
      'filename' => 'modEvent/585b4ec3e9fd4ee0ca6bb140f62bca85.vehicle',
    ),
    150 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd228a3049dd5927534881051dd3e486a',
      'native_key' => 'OnManagerPageBeforeRender',
      'filename' => 'modEvent/73e6592d4f214a62314f7cad5bb06bae.vehicle',
    ),
    151 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '69fcb70a35050bba397cc2f22fc6799a',
      'native_key' => 'OnManagerPageAfterRender',
      'filename' => 'modEvent/80ad0906ced8d1afce60151644461f8f.vehicle',
    ),
    152 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2d32d4acadf913a3c7e1b0c6206ec711',
      'native_key' => 'OnWebPageInit',
      'filename' => 'modEvent/d8e778252705229f42e6aee4323a222d.vehicle',
    ),
    153 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a24c0b5500960abde0008a2a1417bbca',
      'native_key' => 'OnLoadWebDocument',
      'filename' => 'modEvent/863aeb2a77562fd4fd6f1b369e2c92da.vehicle',
    ),
    154 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2180ba8a91d78a9233ed3740eda8d9e8',
      'native_key' => 'OnParseDocument',
      'filename' => 'modEvent/1c33f467a132e20c4a5476d241184249.vehicle',
    ),
    155 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'abb4277263f7f928c16281286222bb7b',
      'native_key' => 'OnWebPageComplete',
      'filename' => 'modEvent/9a50e8a853ae920a23edd10752ecc75a.vehicle',
    ),
    156 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7ea7848a60ee265bb4ad2bc8a3c80216',
      'native_key' => 'OnBeforeManagerPageInit',
      'filename' => 'modEvent/30b09e90b1d12862dd31567369ec759d.vehicle',
    ),
    157 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'afb36874f1fcc8f8fb42bdd9401b1e0b',
      'native_key' => 'OnPageNotFound',
      'filename' => 'modEvent/e54982e2cfd0bb1625def7cbd62236a4.vehicle',
    ),
    158 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4fb4613e9eb2ae54b10f6c4ec0ce174f',
      'native_key' => 'OnHandleRequest',
      'filename' => 'modEvent/4e961a2f5c3cee8f12909da47481c11b.vehicle',
    ),
    159 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9982cd46ed4c23d00713842f25e4265e',
      'native_key' => 'OnMODXInit',
      'filename' => 'modEvent/d1593d06c601dd59d53ee399e3f9a3b9.vehicle',
    ),
    160 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7f7f2f96d195131d017123ee4b6cb6a9',
      'native_key' => 'OnElementNotFound',
      'filename' => 'modEvent/22dc4d0997f9f3b5dd4fc41949dfaa75.vehicle',
    ),
    161 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5a56bc065fff66261c0a817d0b1ec65d',
      'native_key' => 'OnSiteSettingsRender',
      'filename' => 'modEvent/572fb1d0347db3aa5a3e1bca0ef7c44e.vehicle',
    ),
    162 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0e90d389c1ac3e9aa89d99f6620d81eb',
      'native_key' => 'OnInitCulture',
      'filename' => 'modEvent/0467f23d2979ecf5ddb6fa276c942e07.vehicle',
    ),
    163 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2e6699ca0a2aeab8d9f6ef6e3df3f368',
      'native_key' => 'OnCategorySave',
      'filename' => 'modEvent/f89f9ed8736d3afcdd9cd6bb98c511b3.vehicle',
    ),
    164 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4ee239ce0ec975dd0ccf618099d84b82',
      'native_key' => 'OnCategoryBeforeSave',
      'filename' => 'modEvent/80aef3af9b2326070738b6885d99c6f4.vehicle',
    ),
    165 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7c9d879c1a70ef3e65120e14927fcb27',
      'native_key' => 'OnCategoryRemove',
      'filename' => 'modEvent/69dc84b2345bb40c44095b58f4c4b639.vehicle',
    ),
    166 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '33118fce83d2d215966c30429a7f14bd',
      'native_key' => 'OnCategoryBeforeRemove',
      'filename' => 'modEvent/f87fd703f46dca5e70e523bb5dc9e56e.vehicle',
    ),
    167 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a994bb35d493fa20e543d88251aee510',
      'native_key' => 'OnChunkSave',
      'filename' => 'modEvent/16d069db662dfccf519bdfd2a921e0cd.vehicle',
    ),
    168 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6b38d6f892f17cda45b994b813b07eae',
      'native_key' => 'OnChunkBeforeSave',
      'filename' => 'modEvent/486201979f6c1a893ae01d35ce1dfe5d.vehicle',
    ),
    169 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'acebe78ac71453cdd3e6964affcd3dd2',
      'native_key' => 'OnChunkRemove',
      'filename' => 'modEvent/2223d5f5d2122b4b4daed0b605749d5e.vehicle',
    ),
    170 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '96fc1818b12146e904c141bf328f95d2',
      'native_key' => 'OnChunkBeforeRemove',
      'filename' => 'modEvent/1c6a52f0e0e93097bbf546eb0d8ff506.vehicle',
    ),
    171 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '48c989275d96242e1ba733bc66723d01',
      'native_key' => 'OnChunkFormPrerender',
      'filename' => 'modEvent/4cdc3a8eb311dff55931816efd85b917.vehicle',
    ),
    172 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dec06a52427ec6457bbc3f533d3a5940',
      'native_key' => 'OnChunkFormRender',
      'filename' => 'modEvent/731438c967c4c00ccd149b0050c19f62.vehicle',
    ),
    173 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4cd140cf393e87e4f071c67d150e77a4',
      'native_key' => 'OnBeforeChunkFormSave',
      'filename' => 'modEvent/a6477d6b896ebe71fa5a8b0d3416548a.vehicle',
    ),
    174 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '21f2a5e1794fd42f04d9d902322bb865',
      'native_key' => 'OnChunkFormSave',
      'filename' => 'modEvent/c17c8802aeec00d26e79f69f41e0198d.vehicle',
    ),
    175 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3c260fb118dc1da762e834b61a9bc30f',
      'native_key' => 'OnBeforeChunkFormDelete',
      'filename' => 'modEvent/26e8170586e11f96a6ce0c5aabec99a0.vehicle',
    ),
    176 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '87872c060b685d34574e42cdc95c17f6',
      'native_key' => 'OnChunkFormDelete',
      'filename' => 'modEvent/85a41198dfe719367421abe5276d193c.vehicle',
    ),
    177 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a300a4b2a344cdebfcf2a2497da3fa6d',
      'native_key' => 'OnContextSave',
      'filename' => 'modEvent/690bdd52030af034effe9d55d21df172.vehicle',
    ),
    178 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b26e86d36eb72a8ad2127e1699061e28',
      'native_key' => 'OnContextBeforeSave',
      'filename' => 'modEvent/98f3df7fee703365741b813d22386542.vehicle',
    ),
    179 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '072ef668064cb6c57c317e119ed09025',
      'native_key' => 'OnContextRemove',
      'filename' => 'modEvent/d8f5e36c9681701993817f979a1ad846.vehicle',
    ),
    180 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '66fd600654c7177d9cd177fe72df45f8',
      'native_key' => 'OnContextBeforeRemove',
      'filename' => 'modEvent/4fe62f68fc8e82590bb542a05379f4d1.vehicle',
    ),
    181 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7e1a1402afe00213aba2138650bb4f3e',
      'native_key' => 'OnContextFormPrerender',
      'filename' => 'modEvent/5191ad37d1a7c502fc1dc5c05ab7092d.vehicle',
    ),
    182 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7a18a51fcfb60556036600e05f81db74',
      'native_key' => 'OnContextFormRender',
      'filename' => 'modEvent/64914365e4bf0ac700cd31856b91e4c0.vehicle',
    ),
    183 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5abd55e928030297341850525cb2d160',
      'native_key' => 'OnPluginSave',
      'filename' => 'modEvent/7eb16716329b462feac28db19de36449.vehicle',
    ),
    184 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3b0fac64fcaee42e5c88b8ff70c0b2e2',
      'native_key' => 'OnPluginBeforeSave',
      'filename' => 'modEvent/f3d7d59ca498a2b65eed10dfad32899f.vehicle',
    ),
    185 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '25625a9058212f6dd9072834f7c6d00f',
      'native_key' => 'OnPluginRemove',
      'filename' => 'modEvent/426462a3b0eeb7d1b0afc4acccd68320.vehicle',
    ),
    186 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4a64f0101059c917e1113205969a81f5',
      'native_key' => 'OnPluginBeforeRemove',
      'filename' => 'modEvent/e67bb3b8ff5c4efbb8d73119d15b7a41.vehicle',
    ),
    187 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8575e9e835025cf123460dc4e0d178f4',
      'native_key' => 'OnPluginFormPrerender',
      'filename' => 'modEvent/42b5cff64e2f8f96305def8372882b0e.vehicle',
    ),
    188 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6458aca50927188ad7cd24cf0bff803d',
      'native_key' => 'OnPluginFormRender',
      'filename' => 'modEvent/7bbb71dd804ed39972525f4cfb466042.vehicle',
    ),
    189 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a00a0cb913f771cbe5b6850538009236',
      'native_key' => 'OnBeforePluginFormSave',
      'filename' => 'modEvent/f1565612b72985af878c8fdab1ef2ffa.vehicle',
    ),
    190 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2cfc0d3377888182cb007a29148f0b2b',
      'native_key' => 'OnPluginFormSave',
      'filename' => 'modEvent/369f77cf45d512ed46b02a0760ff645d.vehicle',
    ),
    191 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f0e2f7cf53b9da2ab77954d044d1dfa7',
      'native_key' => 'OnBeforePluginFormDelete',
      'filename' => 'modEvent/fbfb2c891abf12c16c460892054e6c27.vehicle',
    ),
    192 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6fc532d5683beab38620f3243d76ea4d',
      'native_key' => 'OnPluginFormDelete',
      'filename' => 'modEvent/405989248ddbbddd17914c781eae8f0d.vehicle',
    ),
    193 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fd92795abee5dfccebdc8a618500446f',
      'native_key' => 'OnPropertySetSave',
      'filename' => 'modEvent/97dd857335d330756e1b3969c7c1e92e.vehicle',
    ),
    194 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6da0df0a5bb9ef196568a08b8ca7f2a4',
      'native_key' => 'OnPropertySetBeforeSave',
      'filename' => 'modEvent/302c58ef1c5b11327eccb714423112ad.vehicle',
    ),
    195 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'abe1fd2080d7e755177869100dc507f2',
      'native_key' => 'OnPropertySetRemove',
      'filename' => 'modEvent/bb6c8f6a7ff946a1ee45ac9ab8eedfb8.vehicle',
    ),
    196 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2ab235133e30c2680353d774c8570131',
      'native_key' => 'OnPropertySetBeforeRemove',
      'filename' => 'modEvent/7705989338488607f2a560c5a6da2afe.vehicle',
    ),
    197 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a40df3646cff6e3f5ff88bb11bfa9f34',
      'native_key' => 'OnMediaSourceBeforeFormDelete',
      'filename' => 'modEvent/7ff211d27d5b2390c0c8d7996da528df.vehicle',
    ),
    198 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '91b7f51c12558993acc49e2def82b7d7',
      'native_key' => 'OnMediaSourceBeforeFormSave',
      'filename' => 'modEvent/a3a8e0bfd659edfeb84c86161cc93e8c.vehicle',
    ),
    199 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6fe1afe6ae5f7c8d66cc8d14a73c42d6',
      'native_key' => 'OnMediaSourceGetProperties',
      'filename' => 'modEvent/84a6e1d83a91367b2ab69e71137ec26f.vehicle',
    ),
    200 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '531068bce612792bb96289c612f96393',
      'native_key' => 'OnMediaSourceFormDelete',
      'filename' => 'modEvent/7a6e2206d7f97b911407941aee0b8cdf.vehicle',
    ),
    201 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4a514db4acc8bb51e700c779c8243537',
      'native_key' => 'OnMediaSourceFormSave',
      'filename' => 'modEvent/a405cc5068e95c8d4fed34885d7bf9fc.vehicle',
    ),
    202 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a777a6d01a921ea7e3ab144e09b89736',
      'native_key' => 'OnMediaSourceDuplicate',
      'filename' => 'modEvent/f1e1cb8af99fe454438a076a072148dd.vehicle',
    ),
    203 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a53db88ca06441f16e870a770a0fcb22',
      'native_key' => 'access_category_enabled',
      'filename' => 'modSystemSetting/6bee48d8cf31cf96bac708abc423f368.vehicle',
    ),
    204 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '879b746560267b4c8de588e83461f86a',
      'native_key' => 'access_context_enabled',
      'filename' => 'modSystemSetting/fff15e52760fe6e35a3c17c73d818bad.vehicle',
    ),
    205 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bdae64906070c05dcd65f255aa8a5c92',
      'native_key' => 'access_resource_group_enabled',
      'filename' => 'modSystemSetting/fa0a7ca518712a4f76a3b63bed97ffd9.vehicle',
    ),
    206 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '45aedc2f261e38cc6fb6c061b17458ed',
      'native_key' => 'allow_forward_across_contexts',
      'filename' => 'modSystemSetting/35d9a731930d1c59b25cdcbdf4708ff8.vehicle',
    ),
    207 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd43de454e699f71ac10ee842a202699c',
      'native_key' => 'allow_manager_login_forgot_password',
      'filename' => 'modSystemSetting/f96a2d2aa44639e74e11966895a70395.vehicle',
    ),
    208 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9bd12a5d0f1bce9c4b219abc389f94d7',
      'native_key' => 'allow_multiple_emails',
      'filename' => 'modSystemSetting/0b38a317f947fbd943ac9d63db553a63.vehicle',
    ),
    209 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '719b6332a1650f29e67134a3591ef796',
      'native_key' => 'allow_tags_in_post',
      'filename' => 'modSystemSetting/37c04507043b8d2785cf67e01e10bc49.vehicle',
    ),
    210 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '05334060018735f68898b535b2e8882c',
      'native_key' => 'archive_with',
      'filename' => 'modSystemSetting/8e4d6d9b0f6d088d1bbeab707b9da9fd.vehicle',
    ),
    211 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a44cb36b8c27b3d48990b5ab08eeb64d',
      'native_key' => 'auto_menuindex',
      'filename' => 'modSystemSetting/9f69de6e57ae550d9136f2207015afae.vehicle',
    ),
    212 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '95426968463b2529b20c20d17e0adbc3',
      'native_key' => 'auto_check_pkg_updates',
      'filename' => 'modSystemSetting/95220a2d0dce07e0ecceb05ee7297754.vehicle',
    ),
    213 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a9381d1e98df6c7c0d1ba32bd69faaa0',
      'native_key' => 'auto_check_pkg_updates_cache_expire',
      'filename' => 'modSystemSetting/72d033579da3967c41217c6375bb7b7b.vehicle',
    ),
    214 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '04a74d9a13a7ce84081401336fa0e4a9',
      'native_key' => 'automatic_alias',
      'filename' => 'modSystemSetting/2f5fe1544054242c49e30f21bcfa86da.vehicle',
    ),
    215 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3e0c3daf0b275b01a894f9640e587b76',
      'native_key' => 'base_help_url',
      'filename' => 'modSystemSetting/942c8927ab754b2e7e048bed3fcb73d4.vehicle',
    ),
    216 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c63df0acbd28f7784af414299c118b10',
      'native_key' => 'blocked_minutes',
      'filename' => 'modSystemSetting/14652d5039bd70a6839cee29aa69fcd5.vehicle',
    ),
    217 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e83949bb1841094394cef58b96a6484c',
      'native_key' => 'cache_action_map',
      'filename' => 'modSystemSetting/1f81f9466ad8ee79c1c2771f4dd31f43.vehicle',
    ),
    218 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a034dec10d619c0df6ec08f27fcbebd3',
      'native_key' => 'cache_alias_map',
      'filename' => 'modSystemSetting/b259b617a9639423a743d30356f70ca3.vehicle',
    ),
    219 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cc5628b0905a892bbfe99a0d78d7862f',
      'native_key' => 'cache_context_settings',
      'filename' => 'modSystemSetting/9514fc57ec6d253a6f8ac59d1349706b.vehicle',
    ),
    220 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4d15e9dac12da3d0c36beb8eb5394b6d',
      'native_key' => 'cache_db',
      'filename' => 'modSystemSetting/0d2f2e1de60a1af138c266cf829fde52.vehicle',
    ),
    221 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f73de13de69f6d7d2e4841ec0d435bc1',
      'native_key' => 'cache_db_expires',
      'filename' => 'modSystemSetting/d1ec767dd608a1a6da617f3b41522ac9.vehicle',
    ),
    222 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '547287dc37bc0fa9055ffedbf51b4455',
      'native_key' => 'cache_db_session',
      'filename' => 'modSystemSetting/fa3773edddc0d650f69964a48f2abb4f.vehicle',
    ),
    223 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '89637eb522d4165f940a1237368aa723',
      'native_key' => 'cache_db_session_lifetime',
      'filename' => 'modSystemSetting/c915de6795bbde6b96f1bbf4ac5d1fc9.vehicle',
    ),
    224 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '048c07ddec7db97d981fb18c8b7ee4a0',
      'native_key' => 'cache_default',
      'filename' => 'modSystemSetting/0903b65179fbd67ab0a53f7eef49e5d1.vehicle',
    ),
    225 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '61c69d916b0e73fd204bf4c049abf96b',
      'native_key' => 'cache_disabled',
      'filename' => 'modSystemSetting/1be5f26da95957fa470566e5f95344d3.vehicle',
    ),
    226 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f740b79804eba7847e72c2da1976c912',
      'native_key' => 'cache_expires',
      'filename' => 'modSystemSetting/7b1285083ea65889cdb9387d66b18c45.vehicle',
    ),
    227 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c59109156f511cbe10e300240da7b950',
      'native_key' => 'cache_format',
      'filename' => 'modSystemSetting/fdef1d796cfd49dfc80604f35efc0fad.vehicle',
    ),
    228 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'efd819e893060387100b07b905b739e4',
      'native_key' => 'cache_handler',
      'filename' => 'modSystemSetting/69fe0b64e50426df520cc03f7f32142f.vehicle',
    ),
    229 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '395ec149d8becab7edc6ef7cf4d0949f',
      'native_key' => 'cache_lang_js',
      'filename' => 'modSystemSetting/3cd1737fd55727412c8b2c3fe66340d6.vehicle',
    ),
    230 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '033114774a6175f12178298b6057ca8d',
      'native_key' => 'cache_lexicon_topics',
      'filename' => 'modSystemSetting/97e3b0bafbcde310cc78daba6e572e4f.vehicle',
    ),
    231 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bc03362dbe2012d8fd0a9c5cdbe00d69',
      'native_key' => 'cache_noncore_lexicon_topics',
      'filename' => 'modSystemSetting/5141483cde9030706a39b6ab8fcc63eb.vehicle',
    ),
    232 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a4bf9959f3cdb33931df138ccec8f0da',
      'native_key' => 'cache_resource',
      'filename' => 'modSystemSetting/e600c5eb34e07b0429b2a4df99d3aef8.vehicle',
    ),
    233 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f2d54f7a6d40f12e1f1b02bd7bd4fb0a',
      'native_key' => 'cache_resource_expires',
      'filename' => 'modSystemSetting/289534055b4563412185bc7b255e4054.vehicle',
    ),
    234 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '39e1e53058e614072f67758364164214',
      'native_key' => 'cache_scripts',
      'filename' => 'modSystemSetting/4da51d8d1628c73206acf61d4ecdcacc.vehicle',
    ),
    235 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ec48489f77acb72c761e78a1f7919ac4',
      'native_key' => 'cache_system_settings',
      'filename' => 'modSystemSetting/3e35ba2424752d885691d20f28607f8d.vehicle',
    ),
    236 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '44a090870b7f1c9bb46c11aa403010e7',
      'native_key' => 'clear_cache_refresh_trees',
      'filename' => 'modSystemSetting/0e2e81c9f47a717652a7bde642d34c5e.vehicle',
    ),
    237 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e642072491b64a283bf249b23f642a69',
      'native_key' => 'compress_css',
      'filename' => 'modSystemSetting/c6aaf6cfb12b56de1f6491c3629d0739.vehicle',
    ),
    238 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f63f4d51a99a3bbd39fb821bc7bb6a10',
      'native_key' => 'compress_js',
      'filename' => 'modSystemSetting/c7b2fa7f47094ee328aa0b37e3ef0565.vehicle',
    ),
    239 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '91d3e2c039312059d1e5b1b17a222679',
      'native_key' => 'compress_js_max_files',
      'filename' => 'modSystemSetting/c443cb902f7eca5ecf99e23c48e4b653.vehicle',
    ),
    240 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c6869a9c2308631eb4ffa5d89fbfe5cd',
      'native_key' => 'compress_js_groups',
      'filename' => 'modSystemSetting/be68b34671db91e8e2bf6a9c3bae877f.vehicle',
    ),
    241 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f3d12affb8b2981fbfcb8dd34fa5f3ac',
      'native_key' => 'confirm_navigation',
      'filename' => 'modSystemSetting/8f47111e5b9c358f45c99796a67f7ab1.vehicle',
    ),
    242 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a62bb5d0997fcfee3fcf19ef65c6c3b9',
      'native_key' => 'container_suffix',
      'filename' => 'modSystemSetting/38145c9bda0cfdad042491e33fc25483.vehicle',
    ),
    243 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e8494edda4d8b83649648e20d5866fd4',
      'native_key' => 'context_tree_sort',
      'filename' => 'modSystemSetting/e605d5e7112100be5baa4a145ffa9242.vehicle',
    ),
    244 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1c8a096005ddeec4711736a28a26667b',
      'native_key' => 'context_tree_sortby',
      'filename' => 'modSystemSetting/fbb884393e6843d7b8b1699142bf1df4.vehicle',
    ),
    245 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b86481b3c7d7d3be0f6f274a2c0cd1c1',
      'native_key' => 'context_tree_sortdir',
      'filename' => 'modSystemSetting/07953d410f92a38ea9400de8fb8a4313.vehicle',
    ),
    246 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7aa47b845140bc4aa83f51287de1edf3',
      'native_key' => 'cultureKey',
      'filename' => 'modSystemSetting/4e0e8074bd8a33e26fd02496567575a4.vehicle',
    ),
    247 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7a31d071cf0f1cab75f6cc79301b65e9',
      'native_key' => 'date_timezone',
      'filename' => 'modSystemSetting/a25d8e1315e7ddae9fdc117a6a40af40.vehicle',
    ),
    248 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f9114e34bd5d0575f2eb6813f5f76114',
      'native_key' => 'debug',
      'filename' => 'modSystemSetting/116b4cbe20ed0dec06311f0b8b3bb879.vehicle',
    ),
    249 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a66180108910aa7eb18d8e0a0077e8ea',
      'native_key' => 'default_duplicate_publish_option',
      'filename' => 'modSystemSetting/603e815017fae0ec7034b4bc4ecd776c.vehicle',
    ),
    250 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dd263b1a403f548e97067b69c402f24a',
      'native_key' => 'default_media_source',
      'filename' => 'modSystemSetting/a8c361d077a17f08652c71618fde8d82.vehicle',
    ),
    251 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c41613cfcedea4ea8d56a2ebf945b7fb',
      'native_key' => 'default_per_page',
      'filename' => 'modSystemSetting/00cd64c4880951882abfc3efdbca9cc6.vehicle',
    ),
    252 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '61cbe405987e8058c4f5398fe72d1012',
      'native_key' => 'default_context',
      'filename' => 'modSystemSetting/8d64fcb22558433bd2eb2de6b103adc1.vehicle',
    ),
    253 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e4672c79ffe063c3dffb6467bfb2584d',
      'native_key' => 'default_template',
      'filename' => 'modSystemSetting/8b55402a17c605b62a7724e095aaf8f0.vehicle',
    ),
    254 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3f0d3c4d6a63bb85e9f4e2a5d9185477',
      'native_key' => 'default_content_type',
      'filename' => 'modSystemSetting/1e384935f16bd6dced5ede107a6b7d44.vehicle',
    ),
    255 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f77fadc970444ac206de5c0fe9e59bb2',
      'native_key' => 'editor_css_path',
      'filename' => 'modSystemSetting/d64c3d3ea35b1efd84330e622f567897.vehicle',
    ),
    256 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6c26df325f75d591cb5bef1999cdd76d',
      'native_key' => 'editor_css_selectors',
      'filename' => 'modSystemSetting/9072baf6d65fd732784500c386024f1d.vehicle',
    ),
    257 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b13ac76e4c77c22fdcc1c1f7f18bca43',
      'native_key' => 'emailsender',
      'filename' => 'modSystemSetting/865ebd4583d4a2500280aa216cca5cbe.vehicle',
    ),
    258 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '821b17d58a403bc30254b84ede51912f',
      'native_key' => 'emailsubject',
      'filename' => 'modSystemSetting/9cea5e92c430bdf18d2562afb4b12197.vehicle',
    ),
    259 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2e642f279803fd4126bb5b6681d5cf27',
      'native_key' => 'enable_dragdrop',
      'filename' => 'modSystemSetting/c0f1411abf1de476c1e436ef7d1774a8.vehicle',
    ),
    260 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '91695a096a191e0a371c3f565dced58c',
      'native_key' => 'error_page',
      'filename' => 'modSystemSetting/dabb43385be05d05ea92d63924f86ac2.vehicle',
    ),
    261 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b48d83496b436331d01368771c4b3f00',
      'native_key' => 'failed_login_attempts',
      'filename' => 'modSystemSetting/ffc7fd22000f13c07cfffce8b62f6580.vehicle',
    ),
    262 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f627e9d0467d3f69a93c3045e40662f1',
      'native_key' => 'fe_editor_lang',
      'filename' => 'modSystemSetting/d7590cf34b6098ecd90c3708304f3dcf.vehicle',
    ),
    263 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '03f2b55b96e21e63243dd198c04e054a',
      'native_key' => 'feed_modx_news',
      'filename' => 'modSystemSetting/706521fa2d0445de7b60565912113165.vehicle',
    ),
    264 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '09cf03cad0ccbbe118d5133fb3bae922',
      'native_key' => 'feed_modx_news_enabled',
      'filename' => 'modSystemSetting/bee2aceca89f2cdbfcb9e2b7c401f565.vehicle',
    ),
    265 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '857156224f5146b92f90c49a4332bc01',
      'native_key' => 'feed_modx_security',
      'filename' => 'modSystemSetting/ad25792b82b0a878b215040388a86e41.vehicle',
    ),
    266 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '597f6032ef50cc59c8761eb457100409',
      'native_key' => 'feed_modx_security_enabled',
      'filename' => 'modSystemSetting/248e2fe214b695192ec99f9160e41fd3.vehicle',
    ),
    267 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e540ca370a6ccd6fb9f77d4ea5f7bb17',
      'native_key' => 'filemanager_path',
      'filename' => 'modSystemSetting/7a4b774c21e9a57077eef9475a74339f.vehicle',
    ),
    268 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8dcbf4e76b4bb08ad3e2a2d243fca070',
      'native_key' => 'filemanager_path_relative',
      'filename' => 'modSystemSetting/05b4b87e702e15d8d84d5fbb11be6522.vehicle',
    ),
    269 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '22aff3c17dbad582cf6d9e93e88963fc',
      'native_key' => 'filemanager_url',
      'filename' => 'modSystemSetting/516d9f2073f57a4b7493e3e096ea489c.vehicle',
    ),
    270 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '48e53465d4fc43a68b906cb1bb092e18',
      'native_key' => 'filemanager_url_relative',
      'filename' => 'modSystemSetting/2fd7d47f8c2bd28129979b6eae59cef1.vehicle',
    ),
    271 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6333c7f34d8dcbe7ea1676fde26d470b',
      'native_key' => 'forgot_login_email',
      'filename' => 'modSystemSetting/912361ded39e5529ae6bcc322acce786.vehicle',
    ),
    272 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '826250e12dda661bcb8c2985a7529764',
      'native_key' => 'form_customization_use_all_groups',
      'filename' => 'modSystemSetting/35541ae36e813fac6428dcdebf28e42b.vehicle',
    ),
    273 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bdc02d8b4c6f8b2314bad2b0ecd39c28',
      'native_key' => 'forward_merge_excludes',
      'filename' => 'modSystemSetting/a72da3b5c2553ee2390f1d12f27f4c18.vehicle',
    ),
    274 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '98bc372b7d5ffbc2442f2673216c1d24',
      'native_key' => 'friendly_alias_lowercase_only',
      'filename' => 'modSystemSetting/3eb4dbc744d852f7aceadf464e8ba10a.vehicle',
    ),
    275 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1baf227a498bc6b12b5a964c207b081e',
      'native_key' => 'friendly_alias_max_length',
      'filename' => 'modSystemSetting/975ac11be1e231d0a7c2c072110c123c.vehicle',
    ),
    276 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e3476009aeaa07246cbfe57aad3a83a0',
      'native_key' => 'friendly_alias_realtime',
      'filename' => 'modSystemSetting/417800c16c51536d836f87809d8df8af.vehicle',
    ),
    277 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0d92f5daaddb73dff18b55522016ec94',
      'native_key' => 'friendly_alias_restrict_chars',
      'filename' => 'modSystemSetting/81b228dbe3b73c01fcd31c558ac5bd3f.vehicle',
    ),
    278 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'efc2b8826e793c8b490394939c42602b',
      'native_key' => 'friendly_alias_restrict_chars_pattern',
      'filename' => 'modSystemSetting/d8bfe7c46b62ad9affb4a336646bf60e.vehicle',
    ),
    279 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e93a94b3cb5b92ff8bde4a0e9e5c4af6',
      'native_key' => 'friendly_alias_strip_element_tags',
      'filename' => 'modSystemSetting/0ba85d5c6926db695c04cd6d207402ab.vehicle',
    ),
    280 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '38bea0c33c7486e58bbd3bb8cddac6a9',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'modSystemSetting/02dc45e2181d4ae715dea905fe08c0d8.vehicle',
    ),
    281 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a90a4e997f8018ebb67c12de199bbb37',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'modSystemSetting/9ece3fe1df77ee3426b806cd3b264545.vehicle',
    ),
    282 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ec48ea2f2b87e313304c97e16569b777',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'modSystemSetting/d6535b94c3e1760d9fb571d5f8d9b311.vehicle',
    ),
    283 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '99e30eb50ef613e19d0a1875933e225d',
      'native_key' => 'friendly_alias_trim_chars',
      'filename' => 'modSystemSetting/bf033841bd7ff75381669989cf724383.vehicle',
    ),
    284 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a5cda74ad4708c9e28213b74d94820f3',
      'native_key' => 'friendly_alias_word_delimiter',
      'filename' => 'modSystemSetting/2acf6ce82f77dded2be8738a7bf627c9.vehicle',
    ),
    285 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ce35af247987a02cdeea5496fd225d14',
      'native_key' => 'friendly_alias_word_delimiters',
      'filename' => 'modSystemSetting/f624dc9dfec80573eddf203c7ac879f5.vehicle',
    ),
    286 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f31af7f09f7b88d447b834aa8ba6584b',
      'native_key' => 'friendly_urls',
      'filename' => 'modSystemSetting/c09239d3ff4442ea5d9dc0734dbd9c2a.vehicle',
    ),
    287 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4e35aa97cf2425aedb51f64ae6ea9091',
      'native_key' => 'friendly_urls_strict',
      'filename' => 'modSystemSetting/a515d72f906a9a26a99f0bf5b8e00fa3.vehicle',
    ),
    288 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7814861d1d1c2b1e93a42fe0dd53a715',
      'native_key' => 'use_frozen_parent_uris',
      'filename' => 'modSystemSetting/490397fe44437d78fd15a4256c9604d6.vehicle',
    ),
    289 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd1e8c4463c027e9b3ec45d5be5beb08e',
      'native_key' => 'global_duplicate_uri_check',
      'filename' => 'modSystemSetting/de33da056a6be660d4c03e28080a9216.vehicle',
    ),
    290 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ad6dda0c9f7cf0f48250c4697d08affb',
      'native_key' => 'hidemenu_default',
      'filename' => 'modSystemSetting/0a2afd47ca7572c364e8e03a64c6371e.vehicle',
    ),
    291 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '067a1aefc3cabc0cb040500bda7af27b',
      'native_key' => 'inline_help',
      'filename' => 'modSystemSetting/695635c8fa2e7e4c312f3d93740d8db8.vehicle',
    ),
    292 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '137091204b6b999da6ce6112a925ef1b',
      'native_key' => 'locale',
      'filename' => 'modSystemSetting/d26cea9c3a7a06ee4f190423ea1fe00c.vehicle',
    ),
    293 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'de61bdb08da30918455f4c6324264ed7',
      'native_key' => 'log_level',
      'filename' => 'modSystemSetting/4de417eb6825eedd029ae539de304639.vehicle',
    ),
    294 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '72331c3f29943c6120ce9ccca507de6c',
      'native_key' => 'log_target',
      'filename' => 'modSystemSetting/bb5263fe15ca02946f0ce19e1b7e9313.vehicle',
    ),
    295 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ae70df7693ed5deefb9c2ccf9644eb0b',
      'native_key' => 'link_tag_scheme',
      'filename' => 'modSystemSetting/84fa8f146004c10d740b7b6d33dc4e48.vehicle',
    ),
    296 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '83c26d288351d56587382ed38726b147',
      'native_key' => 'lock_ttl',
      'filename' => 'modSystemSetting/121f169a3bb41c1ad3c3cad6331344ee.vehicle',
    ),
    297 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e4d72f500f9d43976481b6a185c1a266',
      'native_key' => 'mail_charset',
      'filename' => 'modSystemSetting/b33b8bcc3ddd49ea2ba4757a0e8ffdf4.vehicle',
    ),
    298 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b3b5ce910f7bea6a1442d20c41c38367',
      'native_key' => 'mail_encoding',
      'filename' => 'modSystemSetting/861a713d3c885a3a6f87ba1a1fd1114f.vehicle',
    ),
    299 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ad9754e5b51bb395b42c86b480bf935f',
      'native_key' => 'mail_use_smtp',
      'filename' => 'modSystemSetting/fc031cfe4cf30dab107e6ad056e42f1f.vehicle',
    ),
    300 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1c0a05561811378b882c82b05b1cb35b',
      'native_key' => 'mail_smtp_auth',
      'filename' => 'modSystemSetting/ee1bc774c4741042d288fce43e1805a1.vehicle',
    ),
    301 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd4bb7e0051164ff50ec7cd7db8fd985e',
      'native_key' => 'mail_smtp_helo',
      'filename' => 'modSystemSetting/3008e68e4500ec07c5abe1bf9bb07e1a.vehicle',
    ),
    302 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '84eea4ae8c9c267a66ba0f5b1eb9dc27',
      'native_key' => 'mail_smtp_hosts',
      'filename' => 'modSystemSetting/85091b48dbd4e792f29bf77a68eee9a9.vehicle',
    ),
    303 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2f551efb54eef70f951539367bd1c200',
      'native_key' => 'mail_smtp_keepalive',
      'filename' => 'modSystemSetting/ea5d6f21176060b66bfaeab52b20b766.vehicle',
    ),
    304 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '56aa7eb50880eba54add351818e0ac68',
      'native_key' => 'mail_smtp_pass',
      'filename' => 'modSystemSetting/5db8ab45e58c38deac68db379dbf2754.vehicle',
    ),
    305 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e1857f574967f5564c8f9a1e99203a60',
      'native_key' => 'mail_smtp_port',
      'filename' => 'modSystemSetting/df410486a8c311f0ed2f2515d6e4f1fe.vehicle',
    ),
    306 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '449c2f531b6a89b31a4ef932ce63266d',
      'native_key' => 'mail_smtp_prefix',
      'filename' => 'modSystemSetting/67ba31649cbc990ed701d5a908217d67.vehicle',
    ),
    307 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a9b687d0fd85eb6b885d38fdceb0a77a',
      'native_key' => 'mail_smtp_single_to',
      'filename' => 'modSystemSetting/374a13f9a96f47137a7ff49e975b161e.vehicle',
    ),
    308 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eb5fa3b17b1a155f925f6e6d60466b43',
      'native_key' => 'mail_smtp_timeout',
      'filename' => 'modSystemSetting/7a6899be7c62c04ca3029ca05e64afc7.vehicle',
    ),
    309 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c99b775bb93e621d1bccea32c713c739',
      'native_key' => 'mail_smtp_user',
      'filename' => 'modSystemSetting/e5e940420c4df20c929c4a990afb48f6.vehicle',
    ),
    310 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '004aa45f9e393a22781ea1934f8c5d48',
      'native_key' => 'manager_date_format',
      'filename' => 'modSystemSetting/e98532b1866246a01ff544fc8f627f9b.vehicle',
    ),
    311 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e35370829bd7c5d3491c4d57dc42d018',
      'native_key' => 'manager_favicon_url',
      'filename' => 'modSystemSetting/e67c58e481ab7bd90f465698bf049da0.vehicle',
    ),
    312 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4e52819fa25c9516cf5d2938de071b94',
      'native_key' => 'manager_html5_cache',
      'filename' => 'modSystemSetting/02f1acefa40230de14be438337f51c2e.vehicle',
    ),
    313 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c40c9997dcc60257df60ccf2d2b014c2',
      'native_key' => 'manager_js_cache_file_locking',
      'filename' => 'modSystemSetting/43db0113900c5e3724802c75e68d9e28.vehicle',
    ),
    314 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7437c68d8930fc1e93e49d5234a72483',
      'native_key' => 'manager_js_cache_max_age',
      'filename' => 'modSystemSetting/d64069c468813f19d8d802f947ad02ef.vehicle',
    ),
    315 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'da2270a008fb9b0559f9f7f8583058d0',
      'native_key' => 'manager_js_document_root',
      'filename' => 'modSystemSetting/a22eeb61b1f9745bed20cbf0af2eab67.vehicle',
    ),
    316 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '151f7aa5cba0b44f1e4e4504482b52ab',
      'native_key' => 'manager_js_zlib_output_compression',
      'filename' => 'modSystemSetting/f3e0075baceb4b90aa6fd8e21e7dc693.vehicle',
    ),
    317 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eaf38f3c8c708451cf2d5dcf694df1ed',
      'native_key' => 'manager_time_format',
      'filename' => 'modSystemSetting/45ecbb6573f3b1bd6d71567b0848c0ba.vehicle',
    ),
    318 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c723129b828bbd2c70ba00aff22809ea',
      'native_key' => 'manager_direction',
      'filename' => 'modSystemSetting/36af0cd841c8d7ca646003e0bd5bad1f.vehicle',
    ),
    319 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5ed03de79f6fdbfeb36cce0e759afccb',
      'native_key' => 'manager_lang_attribute',
      'filename' => 'modSystemSetting/0ab9ab2df0b96891aec014b5319fd965.vehicle',
    ),
    320 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '90791dc1b8fda23e5c0121eb6303ae3e',
      'native_key' => 'manager_language',
      'filename' => 'modSystemSetting/55d5973c6a28b61372ebe03db6b5bf5a.vehicle',
    ),
    321 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7c57ae7bf6b0220c03c35e6dc7c35f31',
      'native_key' => 'manager_login_url_alternate',
      'filename' => 'modSystemSetting/102cc028c11693978680b7b9e4b73112.vehicle',
    ),
    322 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3322ecd8304f06fa4c3988b4a403779b',
      'native_key' => 'manager_theme',
      'filename' => 'modSystemSetting/3fd574784dba92742a3f6c9f2190d979.vehicle',
    ),
    323 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7daa9b0251291b925725589ad52ebd93',
      'native_key' => 'manager_week_start',
      'filename' => 'modSystemSetting/13ef74c1bf3045338865b01215f7af78.vehicle',
    ),
    324 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7410d4db7f5b84cd0be5682d6eb84535',
      'native_key' => 'modx_browser_tree_hide_files',
      'filename' => 'modSystemSetting/f0f1f8e43671eefd7068bee1c85b2ae1.vehicle',
    ),
    325 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9dcda29337e37ad2dcea97582c419436',
      'native_key' => 'modx_browser_tree_hide_tooltips',
      'filename' => 'modSystemSetting/0c41d96505e1bfabf7ab907d290e7c78.vehicle',
    ),
    326 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '948024fabb1a1e2cb45b666ad988315b',
      'native_key' => 'modx_browser_default_sort',
      'filename' => 'modSystemSetting/5301fc3f409a6ad1479b27af4f61304e.vehicle',
    ),
    327 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'da1dc9f428cd0268f39233df0f42cdb2',
      'native_key' => 'modx_browser_default_viewmode',
      'filename' => 'modSystemSetting/c2ea415025d4fcbac933190a82fa04e5.vehicle',
    ),
    328 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4fc60934d163bb74087ac4f677c211d5',
      'native_key' => 'modx_charset',
      'filename' => 'modSystemSetting/b1a99ebc50aed05c83a58e9bb076f91c.vehicle',
    ),
    329 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fcd76b775462298b57ac9e3f8cb5e5b3',
      'native_key' => 'principal_targets',
      'filename' => 'modSystemSetting/7f0c2ac7e84c9c14d21c402231584119.vehicle',
    ),
    330 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4ff0d95a1cc635b3153675e128c01cc9',
      'native_key' => 'proxy_auth_type',
      'filename' => 'modSystemSetting/1d008821e4345d279aaa1998499ad85c.vehicle',
    ),
    331 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '60d9aa6bf73a3cfa380dcbd03cb0c500',
      'native_key' => 'proxy_host',
      'filename' => 'modSystemSetting/cb1a57b481414a5951eb250f4301fac1.vehicle',
    ),
    332 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7773c100747f78c952b42f8507e36393',
      'native_key' => 'proxy_password',
      'filename' => 'modSystemSetting/6b16d031b275940213dba6135aeebfc1.vehicle',
    ),
    333 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b03c3dbf319653e4c9e85a30c9adda42',
      'native_key' => 'proxy_port',
      'filename' => 'modSystemSetting/645707f978c04af55577339723f90fb5.vehicle',
    ),
    334 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c4da5214c51d93fd1036676952f98baa',
      'native_key' => 'proxy_username',
      'filename' => 'modSystemSetting/dd13f4e9ad00bdb2e04a04349c46bc8f.vehicle',
    ),
    335 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3313be5626dec321cf560acbefdc2dc0',
      'native_key' => 'password_generated_length',
      'filename' => 'modSystemSetting/3331f54219e7ab956aead83d92da676e.vehicle',
    ),
    336 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f57e71a8700d0e6e8ceca4e300edc868',
      'native_key' => 'password_min_length',
      'filename' => 'modSystemSetting/fd86819190116a5afa811f20a86a62ba.vehicle',
    ),
    337 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ee838a2a106fd11c05f5b4460d88eb8e',
      'native_key' => 'phpthumb_allow_src_above_docroot',
      'filename' => 'modSystemSetting/f494e5fae64e7ad3cbd5fe758a408d13.vehicle',
    ),
    338 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'def0439e72f245df6e4b434673e07224',
      'native_key' => 'phpthumb_cache_maxage',
      'filename' => 'modSystemSetting/86623ee1cef09fccb3e2ed0402779e9e.vehicle',
    ),
    339 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6e851095fe83d023c08cd7bc8058410b',
      'native_key' => 'phpthumb_cache_maxsize',
      'filename' => 'modSystemSetting/b7fc554202dbec8753e0f4a4463481c8.vehicle',
    ),
    340 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ac2c34b883f0de264952b07b18d4737b',
      'native_key' => 'phpthumb_cache_maxfiles',
      'filename' => 'modSystemSetting/b43505179a15bb35bbf7ad71d6fc2806.vehicle',
    ),
    341 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f3f6285942f5a3cd5879ea023c1cb24b',
      'native_key' => 'phpthumb_cache_source_enabled',
      'filename' => 'modSystemSetting/1df47fa42441be320504ceebf989f63c.vehicle',
    ),
    342 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fe408164a3d38bf919264cc305a285df',
      'native_key' => 'phpthumb_document_root',
      'filename' => 'modSystemSetting/9ce76800c7f46fe79d3fedb47761d5b3.vehicle',
    ),
    343 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fff502ed1b4f5efa6316d250de51c835',
      'native_key' => 'phpthumb_error_bgcolor',
      'filename' => 'modSystemSetting/83c44d5d995ce1ec654105edee38dc70.vehicle',
    ),
    344 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3d14bc905ca59fc32c6ed46e6c62ae3c',
      'native_key' => 'phpthumb_error_textcolor',
      'filename' => 'modSystemSetting/cd837a8b8175f479df286ded47888c54.vehicle',
    ),
    345 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '100ed019c3659f2c0f17c8fb06c2a73f',
      'native_key' => 'phpthumb_error_fontsize',
      'filename' => 'modSystemSetting/e5f910bf8ad728515f84307b582bc092.vehicle',
    ),
    346 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a107cc655787947c2f72ef56ac13c2de',
      'native_key' => 'phpthumb_far',
      'filename' => 'modSystemSetting/aabcbd66f47ed08fcf0b2bc0bd5a6ebe.vehicle',
    ),
    347 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cb22c877c4b6e09d999e2296f6e363b9',
      'native_key' => 'phpthumb_imagemagick_path',
      'filename' => 'modSystemSetting/5316e276635aad72ea84afc93700a176.vehicle',
    ),
    348 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '645d5fcfb5b62b3a51882923b99d8b06',
      'native_key' => 'phpthumb_nohotlink_enabled',
      'filename' => 'modSystemSetting/9e8c0fdcbe7af77c2b4484692b331a96.vehicle',
    ),
    349 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '93cfc66d4902f622946055c05427971b',
      'native_key' => 'phpthumb_nohotlink_erase_image',
      'filename' => 'modSystemSetting/be326e6e4f556d9c953016ed333ac8ac.vehicle',
    ),
    350 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '64336adc8cd6a7411501db265197956f',
      'native_key' => 'phpthumb_nohotlink_valid_domains',
      'filename' => 'modSystemSetting/7bb11310319fbbba8eac06aa91ca9cfa.vehicle',
    ),
    351 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cd7f843c6314c0e8600c6defeca723ae',
      'native_key' => 'phpthumb_nohotlink_text_message',
      'filename' => 'modSystemSetting/f1bbe3083dd1be82b5197aa52b3f4c82.vehicle',
    ),
    352 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '243091114157f0c7b7b0fc7079cd0cbb',
      'native_key' => 'phpthumb_nooffsitelink_enabled',
      'filename' => 'modSystemSetting/fdf83ec1064998cf44f65ca3efa4021b.vehicle',
    ),
    353 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eb0a78134421cd4d07ea78860ef97e3e',
      'native_key' => 'phpthumb_nooffsitelink_erase_image',
      'filename' => 'modSystemSetting/cab4fab5a771b198e503ffb5e31c2135.vehicle',
    ),
    354 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '99b6e7a875de974d0fe171e7ab84f5bb',
      'native_key' => 'phpthumb_nooffsitelink_require_refer',
      'filename' => 'modSystemSetting/50d7d3a254fe5a1d2c556753f3f73fd7.vehicle',
    ),
    355 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '30fde51779dd683abe475083ffca9616',
      'native_key' => 'phpthumb_nooffsitelink_text_message',
      'filename' => 'modSystemSetting/77ebc7cb80a8c75500978d16efd3d117.vehicle',
    ),
    356 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a60052fba8c799646fdf72d0152693a2',
      'native_key' => 'phpthumb_nooffsitelink_valid_domains',
      'filename' => 'modSystemSetting/51e020f07a457ccae4df7895f9ec11b0.vehicle',
    ),
    357 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '413bb8d8396c1db5c0ca757713e77b40',
      'native_key' => 'phpthumb_nooffsitelink_watermark_src',
      'filename' => 'modSystemSetting/798063045201fed5a9a1705684366298.vehicle',
    ),
    358 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3d41798a82d246f46f3115a7046c7630',
      'native_key' => 'phpthumb_zoomcrop',
      'filename' => 'modSystemSetting/29ae63ceacc2ad5821a0db984535ef76.vehicle',
    ),
    359 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4f554ee7d51f10b8d85401068bb9dfbb',
      'native_key' => 'publish_default',
      'filename' => 'modSystemSetting/ba9a7b745a42c03a270d9caae6dc6517.vehicle',
    ),
    360 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c751eb2c7cdbc7509b312879bcabd6ec',
      'native_key' => 'rb_base_dir',
      'filename' => 'modSystemSetting/f0cd44d166b07e898f41522700833057.vehicle',
    ),
    361 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6841991408793a62d2c396021a711390',
      'native_key' => 'rb_base_url',
      'filename' => 'modSystemSetting/e4a42f9b00d3af265ea198af185f2a80.vehicle',
    ),
    362 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ecb6b3e0c36b2c5299aa1c5ffee29215',
      'native_key' => 'request_controller',
      'filename' => 'modSystemSetting/d7edab3c43411fc748f305b6d91bed0c.vehicle',
    ),
    363 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '88d32b218abe9805a8008d9af1311302',
      'native_key' => 'request_method_strict',
      'filename' => 'modSystemSetting/f2a8a01fc13b3ea326d63f241750a3c5.vehicle',
    ),
    364 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4180725200fbfffdb33af795c116edf9',
      'native_key' => 'request_param_alias',
      'filename' => 'modSystemSetting/761600ad6124c2db2df199d34b7eecb2.vehicle',
    ),
    365 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c9eedb546697f6f11a495f7d1f2542f5',
      'native_key' => 'request_param_id',
      'filename' => 'modSystemSetting/63e7540b84bab8cc9bb12806727dda65.vehicle',
    ),
    366 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1a8774f91698fe383509fd322bfc99fd',
      'native_key' => 'resolve_hostnames',
      'filename' => 'modSystemSetting/f7b56925c1400931344f806c28b205eb.vehicle',
    ),
    367 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '78bf76050627da3c21adbe18663153ae',
      'native_key' => 'resource_tree_node_name',
      'filename' => 'modSystemSetting/192178b419a7233b92348ec7603e14b8.vehicle',
    ),
    368 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '398808dd7d7845c31db5037c8a485090',
      'native_key' => 'resource_tree_node_name_fallback',
      'filename' => 'modSystemSetting/b61208396748fed5619be8c2971876b0.vehicle',
    ),
    369 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2c47bc69c1b5333780b064b25a036c84',
      'native_key' => 'resource_tree_node_tooltip',
      'filename' => 'modSystemSetting/191b67fbf62cadb57f08e6f9e4ba1e1b.vehicle',
    ),
    370 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b858406efad5fd7a39c00dba3af06a04',
      'native_key' => 'richtext_default',
      'filename' => 'modSystemSetting/eb50317da5e37053bfb9c3661c14614c.vehicle',
    ),
    371 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ba67fc2c47f62a104126a3752ad2bbe9',
      'native_key' => 'search_default',
      'filename' => 'modSystemSetting/f52d63bd88c7c9493fd781dcbeee31b2.vehicle',
    ),
    372 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a7b4ad7cde6f9424e1cd19d74cb59f6d',
      'native_key' => 'server_offset_time',
      'filename' => 'modSystemSetting/9f6202616159a68e23d928b0b8e6c065.vehicle',
    ),
    373 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '44108bb9cd94ebc89c79b066dabfa67a',
      'native_key' => 'server_protocol',
      'filename' => 'modSystemSetting/1dee050a678738bb56ed82d2740b6ebf.vehicle',
    ),
    374 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd04838edb9ac9639bae3b5eec55fd224',
      'native_key' => 'session_cookie_domain',
      'filename' => 'modSystemSetting/7cac52868d080fe0ad6432b55b0bae74.vehicle',
    ),
    375 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b9d1016d32abba7d4efd21ba1139a610',
      'native_key' => 'default_username',
      'filename' => 'modSystemSetting/4b11ffe5edef33a6c241806d2ec8a810.vehicle',
    ),
    376 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'efe8030c0393dfe4ad392a646b3581b4',
      'native_key' => 'session_cookie_lifetime',
      'filename' => 'modSystemSetting/28aac660a78a7056b5c9b2d7656cdaae.vehicle',
    ),
    377 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e386cb6800e5f5d2375ee0f19c1f25a6',
      'native_key' => 'session_cookie_path',
      'filename' => 'modSystemSetting/76676eaa3a39b47fa31d587e893b33b0.vehicle',
    ),
    378 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5097008c0770b7c91cc7279b69d9ae74',
      'native_key' => 'session_cookie_secure',
      'filename' => 'modSystemSetting/434cda1b938c6a8f316ee027929aaef9.vehicle',
    ),
    379 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '83941c275aee9bdebd90ad58c2e54b52',
      'native_key' => 'session_cookie_httponly',
      'filename' => 'modSystemSetting/677188aa6339a45ce258b3f435577f21.vehicle',
    ),
    380 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '49ce17a872f37ef7faefe5b1a449a4a6',
      'native_key' => 'session_gc_maxlifetime',
      'filename' => 'modSystemSetting/a28b10ea31d461a8b6531209fefe68a6.vehicle',
    ),
    381 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '70a751d782cd4936af2a6b29fb78a8ed',
      'native_key' => 'session_handler_class',
      'filename' => 'modSystemSetting/1de96c6d07a7b49c5ebf1bb3b03251ae.vehicle',
    ),
    382 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'af84d665be6cdfb8c4548048b826d4ea',
      'native_key' => 'session_name',
      'filename' => 'modSystemSetting/2ec51840043aa85a27645b81e0ad195f.vehicle',
    ),
    383 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4fd6f20f9fa340adafc9fdab1ab57011',
      'native_key' => 'set_header',
      'filename' => 'modSystemSetting/d2b94b427347bd8d864772bd6e9796f6.vehicle',
    ),
    384 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '89d3aa2ec8de784146a3d652d5cc127f',
      'native_key' => 'show_tv_categories_header',
      'filename' => 'modSystemSetting/86d46c724f54da0b12624179cd325b2c.vehicle',
    ),
    385 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '05c7936ca5dc8aa64e9bc73269f78b4e',
      'native_key' => 'signupemail_message',
      'filename' => 'modSystemSetting/3417ef8c41b9af4cc8f4c8ab26370bec.vehicle',
    ),
    386 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e84ba73da091f0d57fb00b5022365f61',
      'native_key' => 'site_name',
      'filename' => 'modSystemSetting/d85aa2790bf953cb8c0493cdc0fb59dc.vehicle',
    ),
    387 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aa08e9bfcfed58ee07f432f037205470',
      'native_key' => 'site_start',
      'filename' => 'modSystemSetting/8c1b803676f34126605d7df99c5a34d4.vehicle',
    ),
    388 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1d8d159b0cca41589c27ba07f0db65d5',
      'native_key' => 'site_status',
      'filename' => 'modSystemSetting/ea7f14e2d9e691419bb0c1db19350ad5.vehicle',
    ),
    389 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '547328065b509e93fe4ffa252683e308',
      'native_key' => 'site_unavailable_message',
      'filename' => 'modSystemSetting/abb7a1ce49081242be75e3559fc40a0e.vehicle',
    ),
    390 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a7ab0442c83c6392ab66bae3a5de624d',
      'native_key' => 'site_unavailable_page',
      'filename' => 'modSystemSetting/479715e1895c45fb6d16e1781df3eaf2.vehicle',
    ),
    391 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd0838449aa97d770fe92c2acc3b5e338',
      'native_key' => 'strip_image_paths',
      'filename' => 'modSystemSetting/f734cc6a751a48a618f2c758c4b4018c.vehicle',
    ),
    392 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9cac6beb96f4b061e91809b467903782',
      'native_key' => 'symlink_merge_fields',
      'filename' => 'modSystemSetting/f1d6646796456a3315e9c84120666272.vehicle',
    ),
    393 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '09818a62ec3f5d586112bc07c9286c2f',
      'native_key' => 'syncsite_default',
      'filename' => 'modSystemSetting/47dd7c2ad7f6bc0715f0e4ce8098a189.vehicle',
    ),
    394 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4e0c1e580a7f35d1786ba1ff55b606d6',
      'native_key' => 'topmenu_show_descriptions',
      'filename' => 'modSystemSetting/376fd2a03d438d1e1cfccabe2452615d.vehicle',
    ),
    395 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd8ee5bfeafba6666dfbe69ff1213321d',
      'native_key' => 'tree_default_sort',
      'filename' => 'modSystemSetting/7e44cec7a33a8c179efc6d49b6a15817.vehicle',
    ),
    396 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '483ace496feced27031c90e9f2ffcc21',
      'native_key' => 'tree_root_id',
      'filename' => 'modSystemSetting/2ee47798205d03d7fa52d71d4ff72142.vehicle',
    ),
    397 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c960ea5d23a3691b8a36f37a921270b2',
      'native_key' => 'tvs_below_content',
      'filename' => 'modSystemSetting/6b08ab2cdeb4660dd43c3783b3c2eaff.vehicle',
    ),
    398 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '05c83a8f08e64465304091944f7300ea',
      'native_key' => 'udperms_allowroot',
      'filename' => 'modSystemSetting/592b97f3cc8fee953a8a88a02fcf9059.vehicle',
    ),
    399 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cf9f0a23c2602487977235fbb78c06fd',
      'native_key' => 'unauthorized_page',
      'filename' => 'modSystemSetting/c929f191a7e094b491e1b94d7577262d.vehicle',
    ),
    400 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bcce22c89504f52b16a29087598dae4f',
      'native_key' => 'upload_files',
      'filename' => 'modSystemSetting/f63130302a7471f12081bf31af267966.vehicle',
    ),
    401 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9291144e5cf3550a913c8ec92379f32a',
      'native_key' => 'upload_flash',
      'filename' => 'modSystemSetting/5c2a035e37363452fe62148b8a1f851f.vehicle',
    ),
    402 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'abdd7b95e64c1dbfea63cbe14c17b5ac',
      'native_key' => 'upload_images',
      'filename' => 'modSystemSetting/5eb12992dfbcac4a041bdd2f89ba366d.vehicle',
    ),
    403 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9cb1cf00aa0ac6fb28c9dd6aa000eca7',
      'native_key' => 'upload_maxsize',
      'filename' => 'modSystemSetting/8bc57b272e8f5dba7c747a998b9c8195.vehicle',
    ),
    404 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c81c616ced4e9b1c245b49a5108dfa59',
      'native_key' => 'upload_media',
      'filename' => 'modSystemSetting/76efeed1db927d4978571f9b17cd2781.vehicle',
    ),
    405 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8677d23af11cadfb1581e4a932a8a2d8',
      'native_key' => 'use_alias_path',
      'filename' => 'modSystemSetting/efc4a2a0b63457e151bdf0bb6c4dce2e.vehicle',
    ),
    406 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '78d320ae270d65e2bff621382c283304',
      'native_key' => 'use_browser',
      'filename' => 'modSystemSetting/551fbc2cd62ec1cba2466e20176884ee.vehicle',
    ),
    407 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eddae6d99d84b94e70e99e84e838501f',
      'native_key' => 'use_editor',
      'filename' => 'modSystemSetting/b4127455723e9a3ef2fd4523c4211ac6.vehicle',
    ),
    408 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8c695d4e07c491e8ca536afb2d17982a',
      'native_key' => 'use_multibyte',
      'filename' => 'modSystemSetting/0eea893f6f12bd381dc91239ba693c7b.vehicle',
    ),
    409 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6cdd52e78f32a71d1fc881f8b45a9c29',
      'native_key' => 'use_weblink_target',
      'filename' => 'modSystemSetting/d2fda8d2cba6ee752c9fc6ce6c033c9b.vehicle',
    ),
    410 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1379634ae18f908c16ba12bb796dae21',
      'native_key' => 'webpwdreminder_message',
      'filename' => 'modSystemSetting/8010eecfeb555c140d6dc7d744f37ed2.vehicle',
    ),
    411 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '18dc664aa2d9030ee7a03b83940280e3',
      'native_key' => 'websignupemail_message',
      'filename' => 'modSystemSetting/5e35ab1eb0c93dcdd0eb3e872c66ed57.vehicle',
    ),
    412 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'adb99f645f7af4ed4046a80b6e9ff2fd',
      'native_key' => 'welcome_screen',
      'filename' => 'modSystemSetting/684b01d0f6817b73c0e09f4611239a70.vehicle',
    ),
    413 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '318f8f5cde183e51f8caee4f9b231b17',
      'native_key' => 'welcome_screen_url',
      'filename' => 'modSystemSetting/266538bc1defe8f462e149fabde56f97.vehicle',
    ),
    414 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b2b03165299969d2f217bdd6668bcdac',
      'native_key' => 'welcome_action',
      'filename' => 'modSystemSetting/ecf874c4884982c982885f7cf4f313af.vehicle',
    ),
    415 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '09dc90344758507795022acfc5318341',
      'native_key' => 'welcome_namespace',
      'filename' => 'modSystemSetting/e67d0398e7c3c92415b43dd25710ad41.vehicle',
    ),
    416 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1999763c7442c0fb04ed1748a79f1bd9',
      'native_key' => 'which_editor',
      'filename' => 'modSystemSetting/aa852227544db2a3c17a3e8c79aafb1d.vehicle',
    ),
    417 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9570ae2c8e3fce67e753483b537f4883',
      'native_key' => 'which_element_editor',
      'filename' => 'modSystemSetting/c27a1bed222750fb195aef2a86dc6392.vehicle',
    ),
    418 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0697740111933f5fd940aeb524fbbd13',
      'native_key' => 'xhtml_urls',
      'filename' => 'modSystemSetting/16674ee4293391d064488467c936af50.vehicle',
    ),
    419 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4f979ebf067b28048ae077533b06c026',
      'native_key' => 'enable_gravatar',
      'filename' => 'modSystemSetting/2eb0c9f1bb9efa100ff4289895e53fa2.vehicle',
    ),
    420 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5e7fe5ccbd787d4903044c1b2653a9f5',
      'native_key' => 'mgr_tree_icon_context',
      'filename' => 'modSystemSetting/e8b20f7619564f5618c938382a714292.vehicle',
    ),
    421 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '522fd6956a20086e2a4d1b5c6171bcae',
      'native_key' => 'mgr_source_icon',
      'filename' => 'modSystemSetting/3b7d3f134183b5557b0be2b63a5ad663.vehicle',
    ),
    422 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f118eb39d6d951deee45b04facaf05aa',
      'native_key' => 'main_nav_parent',
      'filename' => 'modSystemSetting/acbde06686eddb41879968cb41b6add8.vehicle',
    ),
    423 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dd4d55e1662af0c5caaf9ca7e0ab76d4',
      'native_key' => 'user_nav_parent',
      'filename' => 'modSystemSetting/8168a7e61b3304e82333cc5db20d42ec.vehicle',
    ),
    424 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bc17fe8463148deeddc7aad6943366c7',
      'native_key' => 'auto_isfolder',
      'filename' => 'modSystemSetting/a2fbbc94f15b17da542a16c1239eb8b2.vehicle',
    ),
    425 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd83417ec52c22cefca47207e4e15a144',
      'native_key' => 'manager_use_fullname',
      'filename' => 'modSystemSetting/4d0f95438bf39fb0248692e7bf3b1ee9.vehicle',
    ),
    426 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9e31c4ed37e485973aa9a839a3d6c47f',
      'native_key' => 'parser_recurse_uncacheable',
      'filename' => 'modSystemSetting/edaad85272d76cbc680f2a06d3278661.vehicle',
    ),
    427 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '2873873da26996949bc060491ac088dc',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'allow_tags_in_post',
      ),
      'filename' => 'modContextSetting/ce2bb89361e96c1966b6f2571b509bc8.vehicle',
    ),
    428 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '4cfff0bf4eae6e5645c8b2eea1f59509',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'modRequest.class',
      ),
      'filename' => 'modContextSetting/fde98019a7a5d5f65ee4b63ffd2f71c9.vehicle',
    ),
    429 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => '49fa97c555f66a751bfaab358bacdf68',
      'native_key' => 1,
      'filename' => 'modUserGroup/3e14b87952cca5e43ebf90ad0e0ae88b.vehicle',
    ),
    430 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboard',
      'guid' => '4074cfe5d49f9b5256d858635c4d4428',
      'native_key' => 1,
      'filename' => 'modDashboard/b3054f04bbaa06c7f9dfae008217ded5.vehicle',
    ),
    431 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMediaSource',
      'guid' => '70cc92f35c6022d72c7982392a2993cc',
      'native_key' => 1,
      'filename' => 'modMediaSource/7f85108b4cb89594989c2402faf3831f.vehicle',
    ),
    432 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'facba235d5b2b67c34c1e02773baa7dd',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/35def8b70514d6c12fcc76fe2875f87b.vehicle',
    ),
    433 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '3e4359f77ea318df0a0f9a1dae3dd836',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/5d626138b22d500f52092c35fa204c41.vehicle',
    ),
    434 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '5b30e05df4d6f0e330ba9d93aae8fbdd',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/932c227c38d34c2ab5e67c67f447d644.vehicle',
    ),
    435 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '48c3ba07a69ac94a2af388c1f960c667',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/8b04501ffa780fda8ae6c1ea02d5943c.vehicle',
    ),
    436 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '308420b98e2188f79f2234c88ab775b7',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/2c4289106d4e41790abd8de963010549.vehicle',
    ),
    437 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => 'e98cfae947d5b600786d670b76043f18',
      'native_key' => 1,
      'filename' => 'modUserGroupRole/cbcfa990a8d18c595ffc7a78277f90c2.vehicle',
    ),
    438 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '39fac6cd0472b1b13383ac6ce620fdea',
      'native_key' => 2,
      'filename' => 'modUserGroupRole/b6b99995d7896dc281a2d2779a7b1920.vehicle',
    ),
    439 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '78080fbd90f45a4d828bb799fbcb7157',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/670aaf5e03406d09a616704acdc4be47.vehicle',
    ),
    440 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'dc98a856a9686bb602bb481bbdc4fffd',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/a40bb425e629fa5b878367404b641032.vehicle',
    ),
    441 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '92c648272eb9b4a83a05217a4de562c1',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/4610045376ff8a225696149002093d6f.vehicle',
    ),
    442 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '16d5095c7d013ff0dc301b40244b204f',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/49ae807096e66b9b24e4383e1eee5fb3.vehicle',
    ),
    443 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'e64ecafcf002fd60cef6767289937cd2',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/11aee5367782118c918e18fdd1c60e06.vehicle',
    ),
    444 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'd76af30a28ca73ab08b202b5bcb2c541',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/e70c98450508ae705b9a9c2886ada874.vehicle',
    ),
    445 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '16799927ee1759edef8b6413ef18a57b',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/1944204772ca00b7a62b9fbcc17c31b7.vehicle',
    ),
    446 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '75734bea18a4e5439d18a85f5291bc05',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/288422aa6151f5a459f3421ed4d611af.vehicle',
    ),
    447 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'a9c86f50ce3eeb5460ba59d49a8dcfc2',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/983b33808098ebcad2ba780756d6c2eb.vehicle',
    ),
    448 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '80476f0430e067bb3e2b9d239ea37aee',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/8dc48bc1f76f679114bcc474ecf871a4.vehicle',
    ),
    449 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '1373d97bf11637af8f8e33810c90e22a',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/2629bac61f53d7069649abc736774699.vehicle',
    ),
    450 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '6287c0772f913a6f2fecd59f518114fa',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/c3623252b4492e5193fb0e636fa8343d.vehicle',
    ),
    451 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '0e7b200a553586e1a0f1f0629d7f8435',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/f33f3e7228ddf77d2761200169b2c928.vehicle',
    ),
    452 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'fa7e38fddc63752e1c7e1053ee465fc8',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/4f5b1ee32a0d6e48bc7327e9735bc960.vehicle',
    ),
    453 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'fa83cef33e78a274e31e288f5db6d753',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/e6033da0592766ae7e96f06faa734323.vehicle',
    ),
    454 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'def314e9fb9a6e360f32caf73ecaebde',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/b03e002fad45df8a61b20d695202e229.vehicle',
    ),
    455 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '2d61673f6b4990e7023cb37761a7fd84',
      'native_key' => 4,
      'filename' => 'modAccessPolicy/369ffbd2c7360f82fc8a68b3f09e201b.vehicle',
    ),
    456 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '52bb85853cef25f91682d41f8d5b4805',
      'native_key' => 5,
      'filename' => 'modAccessPolicy/aee849303c8f9745a727c0bd5b233e98.vehicle',
    ),
    457 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '6a8f8fae1ad743f9c53a053f8f5109de',
      'native_key' => 6,
      'filename' => 'modAccessPolicy/4a6c236baf1e710fafae9e97aea3b042.vehicle',
    ),
    458 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '957ef1ec6940681d6aae4e507876177f',
      'native_key' => 7,
      'filename' => 'modAccessPolicy/4a6e1a517284ef026b659bf2fb2e8e74.vehicle',
    ),
    459 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'f11fe8d219e9881b6a1ecf84022e3547',
      'native_key' => 8,
      'filename' => 'modAccessPolicy/546d1b5b9e872be075eb2b94fb376a8b.vehicle',
    ),
    460 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'de1c5751473cbfeddf3ef18b1396db4e',
      'native_key' => 9,
      'filename' => 'modAccessPolicy/24fd68927f3d6c004fe058a1d7a34df5.vehicle',
    ),
    461 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '0050d7ff1f753ed8bf6c8f101d275a0b',
      'native_key' => 10,
      'filename' => 'modAccessPolicy/5fe0f6f390ffa19ab6a0a583af647453.vehicle',
    ),
    462 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '8c7dc284ecf92bb941138d4d8f127ff5',
      'native_key' => 11,
      'filename' => 'modAccessPolicy/2331fe351cfff43a611d62718e2cbbad.vehicle',
    ),
    463 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '69338032792cd09f31138452481c4af6',
      'native_key' => 12,
      'filename' => 'modAccessPolicy/f61ae5a548eade0532f18903833af6e0.vehicle',
    ),
    464 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '0e1da3e6047b7a32d67267faa52d7c06',
      'native_key' => 'web',
      'filename' => 'modContext/6c0ec2021daca96d79b6b22300fd686c.vehicle',
    ),
    465 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '357e8d0821791fb37d91b1750669c94c',
      'native_key' => 'mgr',
      'filename' => 'modContext/35ea56b8256379278879f2171b604f0f.vehicle',
    ),
    466 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '7956a889cca1af9b7888b5d1624b8c5a',
      'native_key' => '7956a889cca1af9b7888b5d1624b8c5a',
      'filename' => 'xPDOFileVehicle/9e975e59b2b6e5040770050ac17a18d9.vehicle',
    ),
    467 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '9a70c8759de6e2b60cf4cf6f34d4a001',
      'native_key' => '9a70c8759de6e2b60cf4cf6f34d4a001',
      'filename' => 'xPDOFileVehicle/8d2df14e84d38e98979d37c2c4d75fc3.vehicle',
    ),
    468 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '4b4efd6297c23e245e88287eba7b9e8f',
      'native_key' => '4b4efd6297c23e245e88287eba7b9e8f',
      'filename' => 'xPDOFileVehicle/beab0d95e61615026d056adc5d784848.vehicle',
    ),
    469 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'dc8712ebb39b69c92596791b5edfdc83',
      'native_key' => 'dc8712ebb39b69c92596791b5edfdc83',
      'filename' => 'xPDOFileVehicle/e212dd4d18365f1eb075fc3da5cdd41f.vehicle',
    ),
  ),
);